library(testthat)
library(inlmisc)

test_check("inlmisc")
